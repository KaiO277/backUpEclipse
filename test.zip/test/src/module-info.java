/**
 * 
 */
/**
 * 
 */
module test {
	requires java.desktop;
}